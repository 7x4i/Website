$('#col-container').waypoint(function() {
    $(".col-3").css({ 
          opacity: "1",
          marginTop: "0"
        });
  }, { offset: 150 });
  
  